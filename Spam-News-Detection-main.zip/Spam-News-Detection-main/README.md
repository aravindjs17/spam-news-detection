# Spam-News-Detection
Dataset is available on Kaggle Search for Dataset as 'Spam-News' dataset

